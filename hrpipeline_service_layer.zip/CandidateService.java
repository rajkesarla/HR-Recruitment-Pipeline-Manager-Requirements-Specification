package com.hrpipeline.services;

public interface CandidateService {
    // Define service methods here
}
