package com.hrpipeline.services;

public interface TalentPoolService {
    // Define service methods here
}
