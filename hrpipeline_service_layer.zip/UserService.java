package com.hrpipeline.services;

public interface UserService {
    // Define service methods here
}
