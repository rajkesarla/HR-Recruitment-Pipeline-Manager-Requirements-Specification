package com.hrpipeline.services;

public interface CandidateNoteService {
    // Define service methods here
}
