package com.hrpipeline.services;

public interface InterviewFeedbackService {
    // Define service methods here
}
