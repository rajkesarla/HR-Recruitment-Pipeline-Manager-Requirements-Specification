package com.hrpipeline.services;

public interface ApplicationStatusHistoryService {
    // Define service methods here
}
