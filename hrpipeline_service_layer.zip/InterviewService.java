package com.hrpipeline.services;

public interface InterviewService {
    // Define service methods here
}
