package com.hrpipeline.services.impl;

import com.hrpipeline.services.TalentPoolService;
import org.springframework.stereotype.Service;

@Service
public class TalentPoolServiceImpl implements TalentPoolService {
    // Implement service methods here
}
