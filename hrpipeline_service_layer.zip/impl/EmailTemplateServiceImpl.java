package com.hrpipeline.services.impl;

import com.hrpipeline.services.EmailTemplateService;
import org.springframework.stereotype.Service;

@Service
public class EmailTemplateServiceImpl implements EmailTemplateService {
    // Implement service methods here
}
