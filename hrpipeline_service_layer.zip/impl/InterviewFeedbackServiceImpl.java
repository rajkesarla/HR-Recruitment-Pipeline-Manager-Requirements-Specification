package com.hrpipeline.services.impl;

import com.hrpipeline.services.InterviewFeedbackService;
import org.springframework.stereotype.Service;

@Service
public class InterviewFeedbackServiceImpl implements InterviewFeedbackService {
    // Implement service methods here
}
