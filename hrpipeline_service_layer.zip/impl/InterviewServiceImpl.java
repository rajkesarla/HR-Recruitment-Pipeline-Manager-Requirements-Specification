package com.hrpipeline.services.impl;

import com.hrpipeline.services.InterviewService;
import org.springframework.stereotype.Service;

@Service
public class InterviewServiceImpl implements InterviewService {
    // Implement service methods here
}
