package com.hrpipeline.services.impl;

import com.hrpipeline.services.JobPostingService;
import org.springframework.stereotype.Service;

@Service
public class JobPostingServiceImpl implements JobPostingService {
    // Implement service methods here
}
