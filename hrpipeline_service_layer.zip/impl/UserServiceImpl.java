package com.hrpipeline.services.impl;

import com.hrpipeline.services.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    // Implement service methods here
}
