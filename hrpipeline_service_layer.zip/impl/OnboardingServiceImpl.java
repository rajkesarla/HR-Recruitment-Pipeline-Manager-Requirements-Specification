package com.hrpipeline.services.impl;

import com.hrpipeline.services.OnboardingService;
import org.springframework.stereotype.Service;

@Service
public class OnboardingServiceImpl implements OnboardingService {
    // Implement service methods here
}
