package com.hrpipeline.services.impl;

import com.hrpipeline.services.ApplicationStatusHistoryService;
import org.springframework.stereotype.Service;

@Service
public class ApplicationStatusHistoryServiceImpl implements ApplicationStatusHistoryService {
    // Implement service methods here
}
