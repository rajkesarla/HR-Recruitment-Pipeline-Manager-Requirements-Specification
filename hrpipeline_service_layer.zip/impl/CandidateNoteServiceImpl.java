package com.hrpipeline.services.impl;

import com.hrpipeline.services.CandidateNoteService;
import org.springframework.stereotype.Service;

@Service
public class CandidateNoteServiceImpl implements CandidateNoteService {
    // Implement service methods here
}
