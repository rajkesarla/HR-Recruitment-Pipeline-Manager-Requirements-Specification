package com.hrpipeline.services.impl;

import com.hrpipeline.services.AuditLogService;
import org.springframework.stereotype.Service;

@Service
public class AuditLogServiceImpl implements AuditLogService {
    // Implement service methods here
}
