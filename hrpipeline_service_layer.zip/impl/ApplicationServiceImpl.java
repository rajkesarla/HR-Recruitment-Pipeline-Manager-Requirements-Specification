package com.hrpipeline.services.impl;

import com.hrpipeline.services.ApplicationService;
import org.springframework.stereotype.Service;

@Service
public class ApplicationServiceImpl implements ApplicationService {
    // Implement service methods here
}
