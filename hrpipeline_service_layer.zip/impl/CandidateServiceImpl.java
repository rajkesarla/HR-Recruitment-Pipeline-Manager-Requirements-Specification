package com.hrpipeline.services.impl;

import com.hrpipeline.services.CandidateService;
import org.springframework.stereotype.Service;

@Service
public class CandidateServiceImpl implements CandidateService {
    // Implement service methods here
}
