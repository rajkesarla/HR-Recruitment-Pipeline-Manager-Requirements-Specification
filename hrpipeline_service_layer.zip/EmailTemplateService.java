package com.hrpipeline.services;

public interface EmailTemplateService {
    // Define service methods here
}
