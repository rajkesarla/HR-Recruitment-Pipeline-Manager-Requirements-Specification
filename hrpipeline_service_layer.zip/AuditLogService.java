package com.hrpipeline.services;

public interface AuditLogService {
    // Define service methods here
}
