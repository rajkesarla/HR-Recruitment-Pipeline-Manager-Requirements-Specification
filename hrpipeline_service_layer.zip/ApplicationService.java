package com.hrpipeline.services;

public interface ApplicationService {
    // Define service methods here
}
