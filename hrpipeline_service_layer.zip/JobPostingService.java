package com.hrpipeline.services;

public interface JobPostingService {
    // Define service methods here
}
