package com.hrpipeline.services;

public interface OnboardingService {
    // Define service methods here
}
