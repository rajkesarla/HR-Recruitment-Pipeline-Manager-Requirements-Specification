package com.hrms.service.impl;

import com.hrms.dto.CandidateDTO;
import com.hrms.entity.Candidate;
import com.hrms.repository.CandidateRepository;
import com.hrms.service.CandidateService;
import com.hrms.util.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CandidateServiceImpl implements CandidateService {
    private final CandidateRepository candidateRepository;
    private final ModelMapperUtil modelMapperUtil;

    @Override
    public CandidateDTO saveCandidate(CandidateDTO dto) {
        Candidate candidate = modelMapperUtil.mapToEntity(dto, Candidate.class);
        return modelMapperUtil.mapToDTO(candidateRepository.save(candidate), CandidateDTO.class);
    }

    @Override
    public List<CandidateDTO> getAllCandidates() {
        return candidateRepository.findAll().stream()
            .map(c -> modelMapperUtil.mapToDTO(c, CandidateDTO.class))
            .collect(Collectors.toList());
    }
}