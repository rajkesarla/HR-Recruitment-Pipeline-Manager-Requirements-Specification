package com.hrms.service.impl;

import com.hrms.dto.ApplicationDTO;
import com.hrms.entity.Application;
import com.hrms.repository.ApplicationRepository;
import com.hrms.service.ApplicationService;
import com.hrms.util.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {
    private final ApplicationRepository applicationRepository;
    private final ModelMapperUtil modelMapperUtil;

    @Override
    public ApplicationDTO apply(ApplicationDTO dto) {
        Application application = modelMapperUtil.mapToEntity(dto, Application.class);
        return modelMapperUtil.mapToDTO(applicationRepository.save(application), ApplicationDTO.class);
    }

    @Override
    public List<ApplicationDTO> listAll() {
        return applicationRepository.findAll().stream()
            .map(app -> modelMapperUtil.mapToDTO(app, ApplicationDTO.class))
            .collect(Collectors.toList());
    }
}