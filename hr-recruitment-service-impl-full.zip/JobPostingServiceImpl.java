package com.hrms.service.impl;

import com.hrms.dto.JobPostingDTO;
import com.hrms.entity.JobPosting;
import com.hrms.repository.JobPostingRepository;
import com.hrms.service.JobPostingService;
import com.hrms.util.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobPostingServiceImpl implements JobPostingService {
    private final JobPostingRepository jobPostingRepository;
    private final ModelMapperUtil modelMapperUtil;

    @Override
    public JobPostingDTO createJobPosting(JobPostingDTO jobPostingDTO) {
        JobPosting job = modelMapperUtil.mapToEntity(jobPostingDTO, JobPosting.class);
        return modelMapperUtil.mapToDTO(jobPostingRepository.save(job), JobPostingDTO.class);
    }

    @Override
    public List<JobPostingDTO> getAllJobPostings() {
        return jobPostingRepository.findAll().stream()
            .map(job -> modelMapperUtil.mapToDTO(job, JobPostingDTO.class))
            .collect(Collectors.toList());
    }
}