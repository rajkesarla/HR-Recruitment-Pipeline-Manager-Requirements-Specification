package com.hrpipeline.service.impl;

import com.hrpipeline.dto.JobPostingDto;
import com.hrpipeline.entity.JobPosting;
import com.hrpipeline.repository.JobPostingRepository;
import com.hrpipeline.service.JobPostingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class JobPostingServiceImpl implements JobPostingService {

    @Autowired
    private JobPostingRepository jobPostingRepository;

    @Override
    public JobPostingDto createJobPosting(JobPostingDto jobPostingDto) {
        JobPosting jobPosting = new JobPosting();
        jobPosting.setTitle(jobPostingDto.getTitle());
        jobPosting.setDescription(jobPostingDto.getDescription());
        jobPosting.setRequirements(jobPostingDto.getRequirements());
        jobPosting.setResponsibilities(jobPostingDto.getResponsibilities());
        jobPosting.setLocation(jobPostingDto.getLocation());
        jobPosting.setDepartment(jobPostingDto.getDepartment());
        jobPosting.setEmploymentType(jobPostingDto.getEmploymentType());
        jobPosting.setStatus("ACTIVE");
        jobPosting = jobPostingRepository.save(jobPosting);
        jobPostingDto.setJobId(jobPosting.getJobId());
        return jobPostingDto;
    }

    @Override
    public List<JobPostingDto> getAllJobPostings() {
        return jobPostingRepository.findAll().stream().map(job -> {
            JobPostingDto dto = new JobPostingDto();
            dto.setJobId(job.getJobId());
            dto.setTitle(job.getTitle());
            dto.setDescription(job.getDescription());
            dto.setRequirements(job.getRequirements());
            dto.setResponsibilities(job.getResponsibilities());
            dto.setLocation(job.getLocation());
            dto.setDepartment(job.getDepartment());
            dto.setEmploymentType(job.getEmploymentType());
            dto.setStatus(job.getStatus());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public Optional<JobPostingDto> getJobPostingById(Long jobId) {
        return jobPostingRepository.findById(jobId).map(job -> {
            JobPostingDto dto = new JobPostingDto();
            dto.setJobId(job.getJobId());
            dto.setTitle(job.getTitle());
            dto.setDescription(job.getDescription());
            dto.setRequirements(job.getRequirements());
            dto.setResponsibilities(job.getResponsibilities());
            dto.setLocation(job.getLocation());
            dto.setDepartment(job.getDepartment());
            dto.setEmploymentType(job.getEmploymentType());
            dto.setStatus(job.getStatus());
            return dto;
        });
    }

    @Override
    public void deactivateJobPosting(Long jobId) {
        jobPostingRepository.findById(jobId).ifPresent(job -> {
            job.setStatus("INACTIVE");
            jobPostingRepository.save(job);
        });
    }
}