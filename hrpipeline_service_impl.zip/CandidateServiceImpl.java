package com.hrpipeline.service.impl;

import com.hrpipeline.dto.CandidateDto;
import com.hrpipeline.entity.Candidate;
import com.hrpipeline.repository.CandidateRepository;
import com.hrpipeline.service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CandidateServiceImpl implements CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Override
    public CandidateDto saveCandidate(CandidateDto candidateDto) {
        Candidate candidate = new Candidate();
        candidate.setUserId(candidateDto.getUserId());
        candidate.setResumeUrl(candidateDto.getResumeUrl());
        candidate.setCoverLetterUrl(candidateDto.getCoverLetterUrl());
        candidate = candidateRepository.save(candidate);
        candidateDto.setCandidateId(candidate.getCandidateId());
        return candidateDto;
    }
}