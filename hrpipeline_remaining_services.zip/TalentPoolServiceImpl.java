package com.hrpipeline.service.impl;

import com.hrpipeline.entity.TalentPool;
import com.hrpipeline.repository.TalentPoolRepository;
import com.hrpipeline.service.TalentPoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TalentPoolServiceImpl implements TalentPoolService {

    @Autowired
    private TalentPoolRepository talentPoolRepository;

    @Override
    public List<TalentPool> getAll() {
        return talentPoolRepository.findAll();
    }

    @Override
    public TalentPool save(TalentPool talentPool) {
        return talentPoolRepository.save(talentPool);
    }
}