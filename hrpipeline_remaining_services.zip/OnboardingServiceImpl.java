package com.hrpipeline.service.impl;

import com.hrpipeline.entity.OnboardingDocument;
import com.hrpipeline.repository.OnboardingRepository;
import com.hrpipeline.service.OnboardingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OnboardingServiceImpl implements OnboardingService {

    @Autowired
    private OnboardingRepository onboardingRepository;

    @Override
    public List<OnboardingDocument> getDocumentsForCandidate(Long candidateId) {
        return onboardingRepository.findByCandidateId(candidateId);
    }
}