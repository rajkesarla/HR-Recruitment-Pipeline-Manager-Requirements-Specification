package com.hrpipeline.service.impl;

import com.hrpipeline.entity.AuditLog;
import com.hrpipeline.repository.AuditLogRepository;
import com.hrpipeline.service.AuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuditLogServiceImpl implements AuditLogService {

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Override
    public void logAction(AuditLog log) {
        auditLogRepository.save(log);
    }
}