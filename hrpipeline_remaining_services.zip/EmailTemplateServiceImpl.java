package com.hrpipeline.service.impl;

import com.hrpipeline.entity.EmailTemplate;
import com.hrpipeline.repository.EmailTemplateRepository;
import com.hrpipeline.service.EmailTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmailTemplateServiceImpl implements EmailTemplateService {

    @Autowired
    private EmailTemplateRepository templateRepository;

    @Override
    public EmailTemplate createTemplate(EmailTemplate template) {
        return templateRepository.save(template);
    }

    @Override
    public List<EmailTemplate> getAllTemplates() {
        return templateRepository.findAll();
    }
}