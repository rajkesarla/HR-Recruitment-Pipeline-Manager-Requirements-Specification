package com.hrpipeline.service.impl;

import com.hrpipeline.dto.InterviewDTO;
import com.hrpipeline.entity.Interview;
import com.hrpipeline.repository.InterviewRepository;
import com.hrpipeline.service.InterviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InterviewServiceImpl implements InterviewService {

    @Autowired
    private InterviewRepository interviewRepository;

    @Override
    public Interview scheduleInterview(InterviewDTO dto) {
        Interview interview = new Interview();
        // set fields from dto
        return interviewRepository.save(interview);
    }

    @Override
    public List<Interview> getInterviewsByApplicationId(Long appId) {
        return interviewRepository.findByApplicationId(appId);
    }
}